"""Protocol-independent security domain."""
