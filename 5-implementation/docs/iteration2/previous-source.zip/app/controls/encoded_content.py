"""Decoded privacy controls cannot redact source offsets safely; reject instead."""
from app.controls import pii, secrets
from app.controls.normalization import InspectionLimit, inspection_views
from app.core.transaction import Finding, text_leaves


def inspect(tx, secrets_enabled=True, pii_enabled=True):
    findings = []
    try:
        for path, text in text_leaves(tx.payload):
            for view in inspection_views(text):
                if view.text == text:
                    continue
                scan = tx.model_copy(update={"payload": view.text})
                if secrets_enabled and secrets.inspect(scan, "BLOCK"):
                    findings.append(Finding(code="SECRET_DETECTED", control="decoded-secrets", path=list(path),
                        rule_id="ENCODED_SECRET_001", category="secret_exposure", severity="critical",
                        title="Secret found in decoded content", remediation="Remove the secret and rotate it if exposed.",
                        evidence={"view_transformations": list(view.transformations)}))
                if pii_enabled and any(method.endswith("decode") for method in view.transformations) and pii.inspect(scan, "BLOCK"):
                    findings.append(Finding(code="ENCODED_PII_DETECTED", control="decoded-privacy", path=list(path),
                        rule_id="ENCODED_PII_002", category="privacy", title="Personal data found in encoded content",
                        remediation="Remove encoded personal data; source spans cannot be safely redacted."))
    except (InspectionLimit, UnicodeError):
        findings.append(Finding(code="INSPECTION_LIMIT_EXCEEDED", control="preprocessing"))
    return findings[:64]
