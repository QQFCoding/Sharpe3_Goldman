"""Bounded inspection views. Never rewrite executable arguments or authorization digests."""
import base64
import binascii
import re
import unicodedata
from dataclasses import dataclass
from urllib.parse import unquote

VERSION = "inspection-views-v1"
MAX_CHARS = 65536
MAX_VIEWS = 8
MAX_DEPTH = 3
CONFUSABLES = str.maketrans({"а": "a", "е": "e", "о": "o", "р": "p", "с": "c", "х": "x",
    "і": "i", "ј": "j", "у": "y", "Α": "A", "Β": "B", "Ε": "E", "Ι": "I", "Ο": "O",
    "Ρ": "P", "Τ": "T", "ο": "o", "ρ": "p", "ι": "i"})
LEET = str.maketrans("013457", "oieast")
BASE64 = re.compile(r"(?<![\w+/=-])[A-Za-z0-9+/_-]{16,}(?:={0,2})(?![\w+/=-])")
FRAGMENTED = re.compile(r"\b(?:[A-Za-z][ \t]){3,}[A-Za-z]\b")


class InspectionLimit(ValueError):
    pass


@dataclass(frozen=True)
class TextView:
    text: str
    transformations: tuple[str, ...] = ()


def normalize(text):
    value = "".join(c for c in unicodedata.normalize("NFKC", text) if unicodedata.category(c) != "Cf")
    value = value.translate(CONFUSABLES)
    value = re.sub(r"\s+", " ", value).strip()
    value = FRAGMENTED.sub(lambda m: re.sub(r"\s", "", m[0]), value)
    # Keep percent escapes and long encoding tokens intact until decoding.
    return re.sub(r"(?<!%)\b[A-Za-z013457]*[013457][A-Za-z013457]*\b",
        lambda m: m[0].translate(LEET) if len(m[0]) <= 15 and any(c.isalpha() for c in m[0]) else m[0], value)


def decoded_candidates(text):
    candidates = []
    if re.search(r"%[0-9a-fA-F]{2}", text):
        candidates.append((unquote(text, errors="strict"), "url_decode"))
    if re.search(r"\\(?:u[0-9a-fA-F]{4}|x[0-9a-fA-F]{2})", text):
        candidates.append((re.sub(r"\\(?:u([0-9a-fA-F]{4})|x([0-9a-fA-F]{2}))",
            lambda m: chr(int(m[1] or m[2], 16)), text), "escape_decode"))
    replacements = []
    for match in BASE64.finditer(text):
        try:
            token = match[0]
            raw = base64.b64decode(token + "=" * (-len(token) % 4), altchars=b"-_", validate=True)
            decoded = raw.decode("utf-8")
            if len(decoded) >= 8 and all(c.isprintable() or c in "\n\r\t" for c in decoded):
                replacements.append((match.start(), match.end(), decoded))
                if len(replacements) > 8:
                    raise InspectionLimit("Too many encoded fragments")
        except (ValueError, UnicodeError, binascii.Error) as exc:
            if isinstance(exc, InspectionLimit):
                raise
            continue
    if replacements:
        value = text
        for start, end, decoded in reversed(replacements):
            value = value[:start] + decoded + value[end:]
        candidates.append((value, "base64_decode"))
    return candidates


def inspection_views(text):
    if not isinstance(text, str):
        raise TypeError("Inspection requires text")
    if len(text) > MAX_CHARS:
        raise InspectionLimit("Inspection input exceeds limit")
    canonical = normalize(text)
    views = [TextView(canonical, ("unicode/spacing",) if canonical != text else ())]
    seen = {canonical}
    total = len(canonical)
    frontier = list(views)
    for _ in range(MAX_DEPTH):
        next_frontier = []
        for view in frontier:
            for value, method in decoded_candidates(view.text):
                value = normalize(value)
                if value not in seen:
                    if len(views) >= MAX_VIEWS or total + len(value) > MAX_CHARS * 4:
                        raise InspectionLimit("Inspection expansion exceeds limit")
                    total += len(value)
                    seen.add(value)
                    new = TextView(value, (*view.transformations, method))
                    views.append(new)
                    next_frontier.append(new)
        frontier = next_frontier
        if not frontier:
            break
    if frontier and any(normalize(value) != view.text for view in frontier for value, _ in decoded_candidates(view.text)):
        raise InspectionLimit("Encoded nesting exceeds inspection depth")
    return views
