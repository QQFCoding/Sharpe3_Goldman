"""Structured instruction-safety rules. Scores are risk signals, not probabilities."""
import hashlib
import re
import time
from dataclasses import dataclass

from app.controls.discussion import security_discussion
from app.controls.normalization import InspectionLimit, inspection_views
from app.core.transaction import Finding, SecurityTransaction, text_leaves

VERSION = "prompt-rules-v2"


@dataclass(frozen=True)
class Rule:
    id: str
    category: str
    pattern: re.Pattern
    title: str
    confidence: float = .95


def rule(id, category, pattern, title, confidence=.95):
    return Rule(id, category, re.compile(pattern, re.I), title, confidence)


RULES = (
    rule("PROMPT_OVERRIDE_001", "instruction_override", r"\b(?:ignore|override|disregard|forget|bypass)\s+(?:all\s+)?(?:previous|prior|above|system|safety|future)\s+(?:instructions|rules|prompts|policy|policies)", "Instruction hierarchy override"),
    rule("PROMPT_DISCLOSURE_002", "prompt_disclosure", r"\b(?:reveal|print|expose|disclose|show)\s+(?:the\s+|your\s+)?(?:hidden\s+(?:system\s+)?(?:instructions|prompt|rules)|(?:secret|confidential|protected)\s+instructions|system\s+prompt|internal\s+configuration)", "Protected instruction disclosure"),
    rule("ROLE_DELIMITER_003", "role_spoofing", r"<\|(?:im_start|system|start_header_id)\|>|\[INST\]\s*<<SYS>>", "Model role delimiter injection", .99),
    rule("EXFILTRATION_004", "data_exfiltration", r"\b(?:send|upload|exfiltrate|export|leak)\b[^.!?]{0,100}\b(?:credentials|secrets|api[ -]?keys|access tokens|private (?:records|notes|data)|confidential (?:records|notes|customer))\b", "Sensitive data transfer instruction"),
    rule("JAILBREAK_005", "jailbreak", r"\b(?:unrestricted|uncensored)\s+(?:assistant|model)\b|\b(?:disable|bypass)\s+(?:safety\s+)?(?:safeguards|safety policy|safety policies|safety rules)", "Safeguard bypass or unrestricted role"),
    rule("AUTHORITY_SPOOF_006", "role_spoofing", r"\b(?:developer override mode|system override)\b", "Untrusted authority spoofing"),
    rule("TOOL_ABUSE_007", "tool_abuse", r"\b(?:bypass|skip|disable)\s+(?:the\s+)?(?:approvals|approval checks|authorization checks)\b", "Approval bypass instruction"),
    rule("MULTILINGUAL_PL_008", "multilingual_override", r"\b(?:zignoruj|pomiń|pomijaj)\s+(?:poprzednie\s+instrukcje|zasady(?:\s+bezpieczeństwa)?)|\b(?:ujawnij|wyślij)\s+(?:tajne|prywatne|ukryte)\s+(?:dane|instrukcje|prompt)", "Polish override or disclosure instruction"),
    rule("MULTILINGUAL_ES_009", "multilingual_override", r"\bignora\s+las\s+instrucciones\s+anteriores|\brevela\s+el\s+prompt\s+del\s+sistema", "Spanish override instruction"),
    rule("MULTILINGUAL_DE_010", "multilingual_override", r"\bignoriere\s+(?:vorherige|alle)\s+anweisungen|\bzeige\s+geheime\s+systemanweisungen", "German override instruction"),
)

# Compatibility for consumers that inspect the historical pattern list.
PATTERNS = [item.pattern.pattern for item in RULES]


def inspect(tx: SecurityTransaction) -> list[Finding]:
    started = time.perf_counter()
    findings = []
    preprocessing = set()
    if not security_discussion(tx):
        try:
            for path, text in text_leaves(tx.payload):
                seen = set()
                for view in inspection_views(text):
                    preprocessing.update(view.transformations)
                    for item in RULES:
                        match = next((m for m in item.pattern.finditer(view.text)
                            if not re.search(r"\b(?:never|do not|don't|must not|should not|cannot|prevent)\s+$",
                                view.text[max(0, m.start() - 24):m.start()], re.I)), None)
                        if match and item.id not in seen:
                            seen.add(item.id)
                            findings.append(Finding(code="PROMPT_INJECTION_PATTERN", control="prompt-patterns",
                                path=list(path), rule_id=item.id, category=item.category,
                                confidence=item.confidence, title=item.title, version=VERSION,
                                description="An instruction-safety pattern matched an inspection view.",
                                remediation="Treat retrieved content as data; remove overrides and require authorized data flows.",
                                evidence={"sha256": hashlib.sha256(text.encode()).hexdigest(),
                                    "matched_pattern": item.id, "view_transformations": list(view.transformations),
                                    "location": "normalized view; offsets do not address executable arguments"}))
                if len(findings) >= 64:
                    break
        except (InspectionLimit, UnicodeError):
            findings.append(Finding(code="INSPECTION_LIMIT_EXCEEDED", control="preprocessing", rule_id="INPUT_LIMIT_001"))
    tx.risk.prompt_injection = max(tx.risk.prompt_injection, max((f.confidence for f in findings), default=0))
    tx.metadata["deterministic_detection"] = {"detector": "prompt-patterns", "type": "deterministic",
        "version": VERSION, "status": "ok", "score": max((f.confidence for f in findings), default=0),
        "verdict": "malicious" if findings else "benign", "latency_ms": (time.perf_counter() - started) * 1000,
        "rule_ids": sorted({f.rule_id for f in findings if f.rule_id}),
        "preprocessing": sorted(preprocessing)}
    return findings
