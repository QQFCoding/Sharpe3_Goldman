"""Path checks apply to file-tool arguments, not legitimate security discussions."""
import re

from app.controls.normalization import inspection_views
from app.core.transaction import Finding, Operation


def inspect(tx):
    if tx.operation not in {Operation.TOOL_CALL, Operation.MCP_TOOL_CALL} or not tx.resource:
        return []
    if "filesystem." not in tx.resource.name or not isinstance(tx.payload, dict):
        return []
    path = tx.payload.get("path")
    if not isinstance(path, str):
        return []
    for view in inspection_views(path):
        value = view.text.replace("\\", "/")
        if ".." in value.split("/") or value.startswith(("/", "~")) or re.match(r"^[A-Za-z]:", value):
            return [Finding(code="UNSAFE_FILE_PATH", control="tool-path", rule_id="TOOL_PATH_001",
                category="path_traversal", title="File path leaves the relative workspace",
                remediation="Use a relative path within the tool's configured workspace.")]
    return []
