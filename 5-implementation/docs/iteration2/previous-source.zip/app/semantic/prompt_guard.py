import asyncio
from pathlib import Path

from app.controls.normalization import inspection_views
from app.core.transaction import text_leaves
from app.semantic.base import SemanticRisk, SemanticUnavailable


class PromptGuardProvider:
    """Prompt Guard 2 binary classifier with overlapping windows; local weights only."""
    provider_id = "prompt_guard"
    preprocessing_version = "inspection-views-v1"
    max_input_chars = 65536
    max_tokens = 16384
    max_windows = 40

    def __init__(self, path: str, cpu_threads: int = 2):
        self.path = path
        self.cpu_threads = cpu_threads
        self.tokenizer = self.model = None
        self._inflight = None

    def _load(self):
        if not Path(self.path).is_dir():
            raise SemanticUnavailable("Prompt Guard weights are not installed")
        import torch
        from transformers import AutoModelForSequenceClassification, AutoTokenizer

        torch.set_num_threads(self.cpu_threads)

        self.tokenizer = AutoTokenizer.from_pretrained(self.path, local_files_only=True, trust_remote_code=False)
        self.model = AutoModelForSequenceClassification.from_pretrained(self.path, local_files_only=True,
            trust_remote_code=False, use_safetensors=True)
        self.model.eval()

    def _analyze(self, texts):
        if sum(len(text) for text in texts) > self.max_input_chars:
            raise SemanticUnavailable("Semantic character budget exceeded")
        import torch
        if self.model is None:
            self._load()
        score = 0.0
        total_tokens = total_windows = 0
        prepared = []
        # Normalize inspection views, preserving each leaf's provenance. Deduplicate within a request.
        seen = set()
        for text in texts:
            views = inspection_views(text)
            # Classify decoded meaning with its surrounding instructions. Encoded tokens alone
            # caused false positives on benign Base64; retain originals only in rule evidence.
            for view in (views[-1],):
                if not view.text or view.text in seen:
                    continue
                seen.add(view.text)
                tokens = self.tokenizer(view.text, return_tensors="pt", truncation=True,
                    max_length=512, stride=64, return_overflowing_tokens=True, padding=True)
                tokens.pop("overflow_to_sample_mapping", None)
                windows = len(tokens["input_ids"])
                total_windows += windows
                total_tokens += int(tokens["attention_mask"].sum())
                if total_windows > self.max_windows or total_tokens > self.max_tokens:
                    raise SemanticUnavailable("Semantic token/window budget exceeded")
                prepared.append(tokens)
        for tokens in prepared:
            for offset in range(0, len(tokens["input_ids"]), 8):
                with torch.inference_mode():
                    logits = self.model(**{k: v[offset : offset + 8] for k, v in tokens.items()}).logits
                    # Prompt Guard 2's malicious class is index 1; reject incompatible model weights.
                    if logits.shape[-1] != 2:
                        raise SemanticUnavailable("Expected Prompt Guard 2 binary classifier")
                    score = max(score, float(torch.softmax(logits, dim=-1)[:, 1].max()))
        return SemanticRisk(prompt_injection=score)

    async def analyze(self, transaction):
        if self._inflight is not None and not self._inflight.done():
            raise SemanticUnavailable("Prompt Guard is busy")
        self._inflight = asyncio.create_task(
            asyncio.to_thread(self._analyze, [t for path, t in text_leaves(transaction.payload)
                if list(path) not in transaction.metadata.get("semantic_trusted_paths", [])
                and not (len(path) == 3 and path[0] == "messages" and path[-1] == "role")
                and path not in {("source",), ("classification",)}])
        )
        self._inflight.add_done_callback(lambda task: task.exception() if not task.cancelled() else None)
        try:
            # A timeout does not create unlimited background inference jobs.
            return await asyncio.shield(self._inflight)
        except Exception as exc:
            raise SemanticUnavailable("Prompt Guard inference unavailable") from exc
