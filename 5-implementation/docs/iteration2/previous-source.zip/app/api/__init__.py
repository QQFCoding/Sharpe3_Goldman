"""HTTP boundaries."""
