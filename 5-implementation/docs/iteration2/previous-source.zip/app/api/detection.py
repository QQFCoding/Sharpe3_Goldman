"""Operator-only, rate-bounded inspection. No upstream/tool execution or approvals."""
import asyncio
import json
import time
from collections import deque
from pathlib import Path
from typing import Literal

from fastapi import APIRouter, Depends, Request
from fastapi.responses import HTMLResponse, JSONResponse
from pydantic import Field

from app.api.dependencies import admin
from app.audit.repository import AuditEvent
from app.controls.base import canonicalize
from app.core.transaction import OperationRequest, Principal, StrictModel
from app.detection.report import detection_report
from app.settings import ROOT

router = APIRouter()


class InspectionRequest(StrictModel):
    text: str = Field(strict=True, max_length=16000)
    source: Literal["user", "retrieved"] = "user"
    compare: bool = False


@router.get("/dashboard", response_class=HTMLResponse)
async def dashboard():
    return HTMLResponse((Path(__file__).resolve().parents[1] / "dashboard.html").read_text(encoding="utf-8"),
        headers={"Content-Security-Policy": "default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'",
            "X-Content-Type-Options": "nosniff", "Cache-Control": "no-store"})


@router.get("/dashboard.js")
async def dashboard_script():
    from fastapi.responses import Response
    return Response((Path(__file__).resolve().parents[1] / "dashboard.js").read_text(encoding="utf-8"),
        media_type="application/javascript", headers={"X-Content-Type-Options": "nosniff"})


@router.get("/dashboard.css")
async def dashboard_style():
    from fastapi.responses import Response
    return Response((Path(__file__).resolve().parents[1] / "dashboard.css").read_text(encoding="utf-8"), media_type="text/css")


@router.post("/admin/detection/inspect", dependencies=[Depends(admin)])
async def inspect(body: InspectionRequest, request: Request):
    runtime = request.app.state.runtime
    if not hasattr(runtime, "inspection_lock"):
        runtime.inspection_lock = asyncio.Lock()
        runtime.inspection_attempts = deque(maxlen=30)
    now = time.monotonic()
    while runtime.inspection_attempts and runtime.inspection_attempts[0] < now - 60:
        runtime.inspection_attempts.popleft()
    if runtime.inspection_lock.locked() or len(runtime.inspection_attempts) >= 30:
        return JSONResponse({"error": "INSPECTION_CAPACITY_EXCEEDED"}, status_code=429)
    runtime.inspection_attempts.append(now)
    async with runtime.inspection_lock:
        started = time.perf_counter()
        pipeline = runtime.pipeline
        snapshot = runtime.policies.active
        tx = pipeline.prepare(OperationRequest(operation="llm_request",
            payload={"messages": [{"role": "tool" if body.source == "retrieved" else "user", "content": body.text}]}),
            Principal(subject="security-operator", tenant_id="operator-inspection"))
        before = time.perf_counter()
        normalized = canonicalize(tx.payload)
        tx.metadata["normalization"] = {"version": "NFKC/format-character removal",
            "changed": normalized != tx.payload, "input_characters": len(body.text),
            "normalized_characters": len(normalized["messages"][0]["content"])}
        tx.payload = normalized
        tx.metadata["stage_latencies"] = {"normalization": time.perf_counter() - before}
        findings = await pipeline.timed(tx, "deterministic", pipeline.controls(tx, snapshot))
        # Comparison evaluates both classifiers; only prompt-pattern findings are omitted
        # from the inference short circuit. They still participate in the OPA decision.
        inference_findings = [f for f in findings if not (body.compare and f.control == "prompt-patterns")]
        await pipeline.semantic_scan(tx, snapshot, inference_findings, high_risk=True)
        decision = await pipeline.decide(tx, snapshot, pipeline.facts(tx, findings, high_risk=True))
        tx.metadata["stage_latencies"]["total"] = time.perf_counter() - started
        report = detection_report(tx, decision, findings)
        report["inspection_only"] = True
        report["comparison_mode"] = body.compare
        tx.metadata["detection_report"] = report
        # Persistence failure refuses report release, matching gateway evidence behavior.
        import hashlib
        try:
            await runtime.audit.append(AuditEvent.from_transaction(tx, decision,
                hashlib.sha256(body.text.encode()).hexdigest(), "0" * 32,
                tx.metadata["stage_latencies"], phase="operator_inspection"))
        except Exception:
            return JSONResponse({"error": "AUDIT_UNAVAILABLE"}, status_code=503)
        return JSONResponse(report, headers={"Cache-Control": "no-store"})


@router.get("/admin/detection/evaluation", dependencies=[Depends(admin)])
async def evaluation():
    from app.evaluation.evidence import source_fingerprint
    current = source_fingerprint()
    reports = {}
    for name in ("baseline", "current"):
        path = ROOT / "artifacts" / f"hybrid-{name}.json"
        if name == "baseline" and not path.is_file():
            path = ROOT / "docs/hybrid-baseline.json"
        if not path.is_file():
            reports[name] = {"status": "missing", "current": False}
            continue
        try:
            report = json.loads(path.read_text(encoding="utf-8"))
            reports[name] = {k: v for k, v in report.items() if k not in {"results", "path"}}
            reports[name]["current"] = report.get("source_fingerprint") == current
            reports[name]["status"] = "historical_baseline" if name == "baseline" else "measured"
        except (OSError, ValueError):
            reports[name] = {"status": "invalid", "current": False}
    path = ROOT / "artifacts/self-test.json"
    try:
        report = json.loads(path.read_text(encoding="utf-8"))
        reports["self_test"] = {**report, "current": report.get("source_fingerprint") == current}
    except (OSError, ValueError):
        reports["self_test"] = {"status": "missing", "current": False}
    return JSONResponse(reports, headers={"Cache-Control": "no-store"})
