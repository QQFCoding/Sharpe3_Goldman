"""Safe local demo services."""
