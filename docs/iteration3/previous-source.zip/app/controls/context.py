"""Local quote/negation evidence, never a whole-request allowlist.

Only a matched span fully inside a quoted/code discussion is downgraded. Other
instructions and hard invariants remain independently actionable.
"""
import re

QUOTES = re.compile(r"```[\s\S]*?```|`[^`\n]+`|\"[^\"\n]+\"|'[^'\n]+'|[«“„][^»”\n]+[»”“]|‘[^’\n]+’")
DISCUSS = re.compile(r"\b(?:explain|analy[sz]e|document|describe|discuss|review|classify|compare|teach|why)\b|\b(?:wyjaśnij|opisz|przeanalizuj|erkläre|beschreibe|explica|analiza|explique|analyse|spiega|descreva|поясни|объясни|vysvětli)\b", re.I)
EXECUTE = re.compile(r"\b(?:then|now|actually|instead|before answering|after explaining|must obey|must follow|carry out|execute|follow that|follow it)\b|\b(?:send|upload|export|copy|put|grant|delegate|disclose|reveal|disable|bypass|ignore|disregard|teraz|następnie|wyślij|ujawnij|zignoruj|dann|jetzt|sende|umgehe|ignoriere|ahora|envía|ignora|revela|ensuite|envoie|révèle|ignora|invia|rivela|agora|envie|revele|надішли|розкрий|ігноруй|отправь|раскрой|игнорируй|pošli|odhal|ignoruj)\b", re.I)
NEGATION = re.compile(r"\b(?:never|do not|don't|must not|should not|cannot|prevent|refuse to|without|nie|nigdy|nicht|niemals|no|non|não|ne|не|ніколи)\s+(?:\w+\s+){0,2}$", re.I)
MENTION = re.compile(r"\b(?:phrase|sentence|string|literal|pattern|fixture|quoted|attacker|attack|known technique|paper|incident|log|why)\b",re.I)
FOLLOW_THROUGH = re.compile(r"\b(?:(?:perform|implement|apply|enact|adopt|follow)(?:\s+the)?\s+(?:it|that|this|(?:quoted|above|given)\s+(?:instruction|directive|command|action)s?)|do\s+(?:it|that)|act on\s+(?:it|that|this))\b",re.I)
EXECUTION_FRAME = re.compile(r"\b(?:then|now|actually|instead|obey me|obey this|must obey|execute|carry out|must follow|you must|follow that|follow it|teraz|następnie|jetzt|ahora|ensuite|agora)\b",re.I)


def explanatory_mention(text):
    # Each risky sentence needs its own discussion frame. An adjacent imperative
    # cannot inherit an exemption from an earlier educational sentence.
    meaningful=False
    for sentence in re.split(r"[.!?\n]",text):
        risky=list(EXECUTE.finditer(sentence)) or list(re.finditer(r"\b(?:uncensored|unrestricted|system prompt|hidden instructions)\b",sentence,re.I))
        if not risky:
            continue
        if all(NEGATION.search(sentence[max(0,m.start()-45):m.start()]) for m in risky):
            continue
        if not DISCUSS.search(sentence[:180]) or not MENTION.search(sentence) or EXECUTION_FRAME.search(sentence) or FOLLOW_THROUGH.search(sentence):
            return False
        meaningful=True
    return meaningful


def quote_spans(text):
    return [(m.start(), m.end()) for m in QUOTES.finditer(text)]


def context_for_match(text, start, end, trusted=True):
    prefix = text[max(0, start-45):start]
    if NEGATION.search(prefix):
        return "negated"
    if trusted and DISCUSS.search(text[max(0,start-180):start]) and quoted_discussion(text,trusted):
        if any(a <= start and end <= b for a,b in quote_spans(text)):
            return "quoted_discussion"
    if trusted and explanatory_mention(text):
        return "explanatory_mention"
    return "instruction"


def quoted_discussion(text, trusted=True):
    """A structural, conservative context adjustment for real model scores."""
    if not trusted:
        return False
    spans = quote_spans(text)
    if not spans:
        return False
    if not any(DISCUSS.search(text[max(0,a-180):a]) for a,b in spans):
        return False
    outside = text
    for a,b in reversed(spans):
        outside = outside[:a] + " [QUOTED DATA] " + outside[b:]
    # Any execution cue outside the data disables the adjustment.
    cues=[*EXECUTE.finditer(outside),*FOLLOW_THROUGH.finditer(outside)]
    return not any(not NEGATION.search(outside[max(0,m.start()-45):m.start()]) for m in cues)


def discussion_context(text,trusted=True):
    return trusted and (quoted_discussion(text,trusted) or explanatory_mention(text))


def observational_question(text):
    return bool(re.fullmatch(r"\s*(?:why\s+(?:is|are|does)|what\s+(?:is|does))\b[^?\n]{1,300}\?\s*",text,re.I)
        and not EXECUTION_FRAME.search(text))
